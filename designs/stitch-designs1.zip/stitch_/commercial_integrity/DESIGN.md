---
name: Commercial Integrity
colors:
  surface: '#f9f9fb'
  surface-dim: '#d9dadc'
  surface-bright: '#f9f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f5'
  surface-container: '#edeef0'
  surface-container-high: '#e8e8ea'
  surface-container-highest: '#e2e2e4'
  on-surface: '#1a1c1d'
  on-surface-variant: '#5d3f3c'
  inverse-surface: '#2f3132'
  inverse-on-surface: '#f0f0f2'
  outline: '#926f6b'
  outline-variant: '#e6bdb8'
  surface-tint: '#c00015'
  primary: '#af0012'
  on-primary: '#ffffff'
  primary-container: '#d81921'
  on-primary-container: '#ffedeb'
  inverse-primary: '#ffb4ac'
  secondary: '#585e6d'
  on-secondary: '#ffffff'
  secondary-container: '#dde2f4'
  on-secondary-container: '#5e6473'
  tertiary: '#005990'
  on-tertiary: '#ffffff'
  tertiary-container: '#0072b7'
  on-tertiary-container: '#e9f2ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb4ac'
  on-primary-fixed: '#410002'
  on-primary-fixed-variant: '#93000d'
  secondary-fixed: '#dde2f4'
  secondary-fixed-dim: '#c1c6d7'
  on-secondary-fixed: '#161c28'
  on-secondary-fixed-variant: '#414755'
  tertiary-fixed: '#cfe4ff'
  tertiary-fixed-dim: '#9acbff'
  on-tertiary-fixed: '#001d34'
  on-tertiary-fixed-variant: '#004a79'
  background: '#f9f9fb'
  on-background: '#1a1c1d'
  surface-variant: '#e2e2e4'
  status-active: '#28A745'
  status-pending: '#FFC107'
  status-rejected: '#EF4444'
  surface-white: '#FFFFFF'
  border-subtle: '#E5E7EB'
typography:
  headline-lg:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '800'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '800'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Manrope
    fontSize: 20px
    fontWeight: '700'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-bold:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '700'
    lineHeight: '1.2'
  label-md:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.2'
  caption:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.2'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  container-margin-desktop: 40px
  container-margin-mobile: 16px
  gutter: 24px
  section-gap: 48px
  component-padding: 16px
---

## Brand & Style

This design system is engineered for the wholesale and retail textile market, focusing on **commercial efficiency, trust, and professional scale**. The brand personality is authoritative yet accessible, mirroring the reliability of a high-volume trading partner. 

The aesthetic follows a **Corporate Modern** style, utilizing a structured card-based layout on a clean, atmospheric background. It prioritizes information density and transactional speed, ensuring that B2B users can navigate large catalogs and complex order dashboards with zero friction. The interface is natively RTL, optimized for Arabic typography to ensure natural scanning patterns for the target demographic. Visual interest is maintained through high-quality product photography and a signature brand red that commands attention for critical actions.

## Colors

The palette is centered around **Jawish Red**, a high-energy primary color used exclusively for branding, primary calls to action, and critical status indicators. This is balanced by a deep **Navy Black** (Secondary) used for navigation and high-contrast text, providing a stable, institutional feel.

The background uses a cool-toned off-white to reduce eye strain during long procurement sessions. Status colors are strictly enforced to provide immediate visual feedback:
- **Active (Green):** Successful transactions and live listings.
- **Pending (Yellow):** Orders awaiting review or processing.
- **Rejected (Light Red):** Cancelled or declined items, distinct from the primary brand red to avoid brand dilution.

## Typography

**Manrope** serves as the universal typeface, chosen for its exceptional legibility in Arabic and its geometric, modern structure. 

- **Hierarchy:** Dramatic weight contrast is used to guide the eye. Prices and Primary Titles use Extra-Bold (800) for immediate recognition.
- **RTL Optimization:** Line heights are slightly increased (1.6 for body text) to accommodate the ascending and descending strokes characteristic of Arabic script.
- **Numbers:** While the UI is Arabic-only, currency and stock numbers should maintain high visibility, often using the Bold weight to stand out within data tables.

## Layout & Spacing

The design system utilizes a **12-column fixed grid** for desktop, ensuring that information remains organized and readable on large monitors common in trade offices. 

- **Breakpoints:**
  - **Mobile (<640px):** Single column layout, 16px side margins.
  - **Tablet (640px - 1024px):** 2-column grid for product cards, 24px margins.
  - **Desktop (>1024px):** Max-width container of 1280px, 4-column product grids.
- **Rhythm:** An 8px spatial system governs all internal component spacing to maintain a clean, rhythmic flow. Large touch targets are prioritized, with a minimum height of 44px for all interactive elements.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** and **Ambient Shadows**. 

- **Surface Strategy:** The main background (#F6F6F8) acts as the lowest layer. Cards and containers are elevated using a pure white (#FFFFFF) surface.
- **Shadow Profile:** Soft, diffused shadows (shadow-md) are applied to product cards and dashboard modules to create a tactile sense of "lift" without looking dated. 
- **Interactive Depth:** On hover, product cards should transition to a slightly deeper shadow (shadow-lg) and a subtle scale effect (1.02x) to signal interactivity. 
- **Overlays:** Modals and fly-out menus use a 60% opacity dark backdrop to focus the user’s attention on the task at hand.

## Shapes

The shape language is **friendly yet professional**, utilizing significant corner rounding to soften the industrial nature of wholesale trading data.

- **Standard Radius:** 0.5rem (8px) for buttons and input fields.
- **Card Radius:** 0.75rem (12px) for all main containers and product cards to provide a modern, "app-like" feel.
- **Status Pills:** Badges and tags use a full pill radius (9999px) to distinguish them clearly from interactive buttons.

## Components

- **Buttons:** Primary buttons use a solid Jawish Red background with white text. Height is fixed at 48px for main actions. Secondary buttons use a Navy Black outline.
- **Cards:** Product cards must feature a high-aspect-ratio image area, a clear price in Bold, and a quick-add button. A subtle 1px border (#E5E7EB) ensures definition on white backgrounds.
- **Dashboard Tables:** Clean, minimalist rows with 16px vertical padding. Use "Zebra striping" with the neutral background color for readability in data-heavy views.
- **Input Fields:** Large, 44px height fields with a 1px border. Focus states must use a 2px Jawish Red border to clearly indicate the active insertion point.
- **Badges:** Clear, high-contrast status pills (e.g., "Active" in Green text on a light green tint) for instant scanning of order statuses.
- **Navigation:** A sticky top header for the brand and search, with a secondary sticky sub-nav for category filters, ensuring tools are always within reach.